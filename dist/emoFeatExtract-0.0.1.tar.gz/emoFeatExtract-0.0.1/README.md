# emoFeatExtract
A feature extraction package for speech emotion recognition.
